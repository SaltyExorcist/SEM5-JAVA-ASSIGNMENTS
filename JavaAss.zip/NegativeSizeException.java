import java.util.Scanner;
public class NegativeSizeException extends Exception {
    public NegativeSizeException(String message) {
        super(message);
    }
}

