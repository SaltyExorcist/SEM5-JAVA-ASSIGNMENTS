import java.util.*;
import java.io.*;
public class A2 {
    public static void main(String[] args)throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int a,b;
        String str;
        System.out.println("Enter a No:");
        a=Integer.parseInt(br.readLine());
        System.out.println("Enter a String:");
        str=br.readLine();
        System.out.println(a);
        }
    }
